/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.bestmusicplayer;

/**
 *
 * @author stevenchung
 */
public class Release {
    
    public Release release;
    public int id;
    public String name;
    
    public Release getRelease() {return release;}
    public int getId() {return id;}
    public String getName() {return name;}
}
